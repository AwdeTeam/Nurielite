class ScalarMultiplier():
	
	def multiply(self, inputArray, scalarValue):
		newArray = []
		for i in range(len(inputArray)):
			newArray.append(int(int(inputArray[i]) + int(scalarValue))

		return newArray
