import numpy

class FileInput():
	print("hello world")